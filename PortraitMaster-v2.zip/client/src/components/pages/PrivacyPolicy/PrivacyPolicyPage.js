import React from 'react';
import { Container } from 'reactstrap';

const PrivacyPolicy = () => (
  <Container>
    <h1>Privacy Policy</h1>
    <p>To do...</p>
  </Container>
);

export default PrivacyPolicy ;
